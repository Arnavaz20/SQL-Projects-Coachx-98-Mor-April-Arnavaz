---TASK 3:
---JOINS:-
---SQL INNER JOIN clause
---1)	Write a Query to 
---A.	To get the information of the department id 1,2, and 3
select*from Employees
select*from Departments

select*from Departments where department_id in (1,2,3)

--B.	To get the information of employees who work in the department id 1, 2 and 3
select Employees.department_id, Departments.department_id from Employees
inner join Departments
on Employees.department_id=Departments.department_id
where Departments.department_id in (1,2,3)
order by Departments.department_id asc

---Write a Query to get the first name, last name, job title, and department name of employees who work in department id 1, 2, and 3.
select*from Departments

select Employees.first_name, Employees.last_name, Jobs.job_title,Departments.department_name from Employees
inner join Departments
on Employees.department_id=Departments.department_id
inner join Jobs
on Employees.employee_id=Jobs.job_id 
where Departments.department_id in (1,2,3)

---- SQL LEFT JOIN clause
---Write a Query :--
---A.	To query the country names of US, UK, and China

select*from countries
select*From Location

select*From countries where country_name in ('United States of America','united kingdom','CHINA')

---B.	query retrieves the locations located in the US, UK and China:
select countries.Country_id, location.country_id from countries
INNER JOIN Location
on countries.Country_id=Location.country_id
where countries.Country_id in ('US','UK','CHINA')

----C.	To join the countries table with the locations table
select *from countries
inner join Location
on Location.country_id=countries.Country_id

---D.	to find the country that does not have any locations in the locations table

select*from countries
select*From Location

select* from countries
left join Location
on countries.Country_id=Location.country_id
where Location.country_id is null

---Write a query to join 3 tables: regions, countries, and locations

select*from countries
select*From Location
select*From Regions

select countries.Country_id,regions.Region_Id,Location.location_id from countries
join Regions on countries.region_id=Regions.Region_Id
join Location on countries.Country_id=Location.country_id

---SQL FULL OUTER JOIN clause

create table Basket(basket_id int primary key,basket_name varchar(255) not null)

create table Fruits(fruit_id int primary key,fruit_name varchar(255) not null, basket_id int)

insert into Basket values (1,'A'),(2,'B'),(3,'C')

INSERT into Fruits values (1,'Apple',1),(2,'Orange',1),(3,'Banana',2),(4,'Strawberry',null)

select*From Fruits
select*from basket

----A.	Write a query to  returns each fruit that is in a basket and each basket that has a fruit, but also returns each fruit that is not in any basket and each basket that does not have any fruit.
select Fruits.fruit_id,Fruits.fruit_name,Fruits.basket_id from Fruits
full outer join Basket
on Fruits.basket_id=Basket.basket_id
order by Fruits.fruit_id, Basket.basket_id

----B.	Write a query to find the empty basket, which does not store any fruit
select Basket.* from Basket
full outer join Fruits
on Basket.basket_id=Fruits.basket_id
where Fruits.fruit_id is null

----C.	Write a query  which fruit is not in any basket
select Fruits.* from Basket
full outer join Fruits
on Basket.basket_id=Fruits.basket_id
where Fruits.fruit_id is null

-----SQL CROSS JOIN clause
create table sales_organization(sales_org_id int primary key, sales_org varchar(255))

create table sales_channel(channel_id int primary key, channel varchar(255))

insert into sales_organization values (1,'Domestic'),(2,'Export')

insert into sales_channel values(1,'Wholesale'),(2,'Retail'),(3,'Ecommerce'),(4,'Tv Shopping')

select*From sales_channel
select*From sales_organization

---Write a Query To find the all possible sales channels that a sales organization 

select sales_organization.sales_org_id,sales_organization.sales_org,sales_channel.channel,sales_channel.channel_id from sales_organization
cross join  sales_channel