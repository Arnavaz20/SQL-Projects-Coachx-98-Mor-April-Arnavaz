---TASK 4:

---SQL GROUP BY clause
select*from Employees
SELECT*FROM Departments

--Questions:-
--Write a  Query 
---A.	to group the values in department_id column of the employees table:

select department_id from Departments
group by department_id

---B.	to count the number of employees by department:
select count(*)'Number of employees',Department_id from Employees
group by department_id

---C.	returns the number of employees by department
select count(*)'Number of employees',Department_id from Employees
group by department_id

---D.	to sort the departments by headcount:
Select count(*) as Employee_Count,Department_Id from Employees
group by Department_Id 
order by Employee_Count asc

----E.	to find departments with headcounts are greater than 5:

select count(*) as Employee_count, department_id from employees
group by department_id
having count(*)>5

---F.	returns the minimum, maximum and average salary of employees in each department.
select department_id, min(salary)'Min salary',max(salary)'max salary',AVG(salary)'avg salary' from Employees
group by department_id

--G.	To get the total salary per department,
select department_id, sum(salary)'Total Salary' from Employees
group by department_id

--H.	groups rows with the same values both department_id and job_id columns in the same group then 
---return the rows for each of these groups
select department_id,job_id, count(*) as employee_count from Employees
group by department_id,job_id


----SQL HAVING clause
--Questions:-
---Write a Query 
---A.	To get the managers and their direct reports, and  to group employees by the managers and to count the direct reports.
select*from Employees
select*from Dependents

select manager_id, count(*) as 'Direct reports' from Employees where manager_id is not null
group by manager_id

---B.	To find the managers who have at least five direct reports
Select Manager_Id, count(*) as 'Direct Reports' from Employees (nolock) where Manager_Id is not null group by Manager_Id having count(*) <=5


---C.	calculates the sum of salary that the company pays for each department and selects only the departments
---with the sum of salary between 20000 and 30000.

select sum(salary) as' total salary', department_id from Employees
group by department_id
having sum(salary) between 20000 and 30000

---D.	To find the department that has employees with the lowest salary greater than 10000
Select Department_Id from Employees 
group by Department_Id 
having min(Salary) > 10000 

---E.	To find the departments that have the average salaries of employees between 5000 and 7000
select avg(salary) as 'Avg salary', department_id from Employees
group by department_id
having avg(salary) between 5000 and 7000