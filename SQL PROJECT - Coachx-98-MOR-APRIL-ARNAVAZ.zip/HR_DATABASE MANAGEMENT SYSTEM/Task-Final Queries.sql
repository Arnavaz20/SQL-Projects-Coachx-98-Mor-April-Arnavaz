---Task-Final Queries

select*from Employees
select*from Departments

---A.	Combine Above two queries using subquery inorder find all departments located at the location whose id is 1700 and find all 
----employees that belong to the location 1700 by using the department id list of the previous query

select *from Employees where department_id in (select department_id from Departments where location_id=1700)

---B.	to find all employees who do not locate at the location 1700
select*from Employees where  department_id not in (select department_id from Departments where location_id=1700)

---C.	finds the employees who have the highest salary
select*From Employees where salary=(select max(salary) from Employees)

---D.	finds all employees who salaries are greater than the average salary of all employees:
select * from Employees  where Salary > (select avg(salary) from Employees)

--E. Finds all departments which have at least one employee with the salary is greater than 10,000:
select * from employees  where Department_Id in (select Department_Id from Employees (nolock) where Salary > 10000)

--F. Finds all departments that do not have any employee with the salary greater than 10,000:
select * from employees where Department_Id not in (select Department_Id from Employees where Salary > 10000)
 
--G. to find the lowest salary by department:
select * from employees (nolock) where Department_Id in (select Department_Id from Employees  where Salary= (select min(Salary) from Employees ))
 
--H. Finds all employees whose salaries are greater than the lowest salary of every department:
select * from Employees e  where Salary > (select min(Salary) from Employees where Department_Id = e.Department_Id)

--I. Finds all employees whose salaries are greater than or equal to the highest salary of every department
select * from Employees e  where Salary >= (select max(Salary) from Employees where Department_Id = e.Department_Id)
	 
--J. Returns the average salary of every department
select Department_Id, AVG(Salary) AS Average_Salary FROM Employees  where Department_Id in (select Department_Id from Employees ) GROUP BY Department_Id


--K. To calculate the average of average salary of departments :
 select round(AVG(Average_Salary),2) AS Average_of_Average_Salary FROM (select AVG(Salary) AS Average_Salary from Employees  group by Department_Id) as Department_Average

--L. Finds the salaries of all employees, their average salary, and the difference between the salary of each employee and the average salary.
select e.Employee_Id, e.Salary, Avg_salary.Avg_salary, e.Salary - Avg_salary.Avg_salary as Salary_Difference
from Employees  e  join (select Department_Id, avg(Salary) AS Avg_Salary from Employees  group by Department_id) as Avg_Salary on e.Department_id = avg_salary.Department_id

