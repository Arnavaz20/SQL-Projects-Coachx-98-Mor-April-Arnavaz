---TASK 2
---Logical Operators and Special  Operators


--1)WRITE A QUERY FOR  LOGICAL OPERATORS and OTHER ADVANCED OPERATORS:-
---Part 1:-
---A.	finds all employees whose salaries are greater than 5,000 and less than 7,000:
select*from Employees

select*From Employees where salary between 5000 and 7000

---B.	finds employees whose salary is either 7,000 or 8,000:
select*from Employees where salary= 7000 or salary=8000

---C.	finds all employees who do not have a phone number:
select*from employees where phone_number is null

--D.	finds all employees whose salaries are between 9,000 and 12,000.
select*from Employees where salary between 9000 and 12000

---E.	finds all employees who work in the department id 8 or 9.
select*from employees where department_id in (8,9)

---F.	finds all employees whose first name starts with the string jo
select*From Employees where first_name like 'jo%'

---G.	finds all employees with the first names whose the second character is  h
select*from Employees where first_name like '_h'

--H.finds all employees whose salaries are greater than all salaries of employees in the department 8:
select*from Employees where salary>all (select salary from Employees where department_id=8)

---Part 2:- 
---A.finds all employees whose salaries are greater than the average salary of every department:
select*from Employees where salary>(select avg(salary) from Employees)

--B.	finds all employees who have dependents:
select*from Dependents

select*from Employees where employee_id in(select employee_id from Dependents)

---C.	to find all employees whose salaries are between 2,500 and 2,900:
select*from Employees where salary between 2500 and 2900

---D.	to find all employees whose salaries are not in the range of 2,500 and 2,900:
select*from Employees where salary not between 2500 and 2900

---E.	to find all employees who joined the company between January 1, 1999, and December 31, 2000:
select*from Employees where hire_date between '1999-01-01' and '1999-12-31'

----F.	to find employees who have not joined the company from January 1, 1989 to December 31, 1999:
select*from Employees where hire_date not between '1989-01-01' and '1999-12-31'

---G.	to find employees who joined the company between 1990 and 1993:
select*From Employees where hire_date between '1990' and '1993'

---Part 3:-
---A.	to find all employees whose first names start with Da
select*from Employees where first_name like 'da%'

---B.	to find all employees whose first names end with er
select*from employees where first_name like '%er'

--C.	to find employees whose last names contain the word an:
select*from Employees where last_name like '%an%'

---D.	retrieves employees whose first names start with Jo and are followed by at most 2 characters:
select*from Employees where first_name like 'jo__'

---E.	to find employees whose first names start with any number of characters and are followed by at most one character:
select*From Employees where first_name like '_%'

---F.	to find all employees whose first names start with the letter S but not start with Sh:
select*from Employees where first_name like 's%' and first_name not like 'sh%'

--Part 4:-
---A.	retrieves all employees who work in the department id 5.
select* from Employees where department_id=5

---B.	To get the employees who work in the department id 5 and with a salary not greater than 5000.
select*from Employees where department_id=5 and salary<=5000

---C.	statement gets all the employees who are not working in the departments 1, 2, or 3.
select*from Employees Where department_id not in (1,2,3)

--D.	retrieves all the employees whose first names do not start with the letter D.
select*from Employees where first_name not like 'D%'

---E.	to get employees whose salaries are not between 5,000 and 1,000.
select*From Employees where salary not between 5000 and 1000

---Part 5:- 
----A.	Write a query to get the employees who do not have any dependents by above image
select*from Employees where employee_id not in (select employee_id from Dependents)

---B.	To find all employees who do not have the phone numbers
select*from Employees where phone_number is null

--C.	To find all employees who have phone numbers
select*from Employees where phone_number is not null

