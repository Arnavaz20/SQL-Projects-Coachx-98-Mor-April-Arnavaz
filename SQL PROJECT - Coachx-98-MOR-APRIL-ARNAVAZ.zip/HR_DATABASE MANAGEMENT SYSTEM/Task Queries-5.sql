---TASK 5 (Other Queries)
---1)SQL UNION operator
---Quetsion:-
---Write a Query to combine the first name and last name of employees and dependents

select*from Employees
select*from Dependents

select first_name+' '+ last_name  as 'Employee name'from Employees
union 
select first_name+' '+ last_name  as ' Dependent name'from Dependents

----2)SQL INTERSECT operator

---Question :-
-----Write a Query to  Applies the INTERSECT operator to the A and B tables and sorts the combined result set by the id column in descending order.
create table A(ID int)
create table B (ID int)

insert into A values(1),(2),(3)

insert into B values(2),(3),(4)

select*from A
select*from B

select ID from A
intersect
select ID from B
order by ID desc

---3)SQL EXISTS operator

---Write a Query 

----A.	finds all employees who have at least one dependent.

select*from Employees
select*from Dependents


select Employees.employee_id,Employees.first_name,Employees.last_name from Employees
where Exists (select 1 from Dependents where Dependents.employee_id=Employees.employee_id)

--B . finds employees who do not have any dependents:

select Employees.employee_id,Employees.first_name,Employees.last_name from Employees
where  not Exists (select 1 from Dependents where Dependents.employee_id=Employees.employee_id)

----4) SQL CASE expression
--A. Suppose the current year is 2000. How to  use the simple CASE expression to get the work anniversaries of employees by 
select Employee_Id, First_Name, Last_Name, Hire_Date, case when 2000 - datepart(year , Hire_Date) < 5 then 'Maverics' when 2000 - datepart(yy , Hire_Date) between 5 and 10 then 'Experienced' when 2000 - datepart(year , Hire_Date) between 11 and 20 then 'Veteran' 
when 2000 - datepart(year , Hire_Date) >20 then 'Legend' end as 'Work Anniversary' from Employees (nolock)

--B. Write a Query  If the salary is less than 3000, the CASE expression returns �Low�. If the salary is between 3000 and 5000, it returns �average�. When the salary is greater than 5000, the CASE expression returns �High�.
select Employee_Id, First_Name, Last_Name, Salary, case when Salary < 3000 then 'Low' when Salary between 3000 and 5000 then 'Average' when Salary > 5000 then 'High' end as 'Salary Category' from Employees (nolock) 

----5) SQL UPDATE statement
---Write a Query to update Sarah�s last name from  Bell to Lopez
select*from Employees
update Employees set last_name='Lopez'
where first_name='Sarah' and last_name='Bell'

select*from Employees where first_name='Sarah' and last_name='Lopez'

