Create database COACHX_SQL_PROJECTS

CREATE TABLE Empdetails(EmployeeId int,FirstName varchar(max),LastName varchar(max),Salary int,
JoiningDate varchar(max),Department varchar(max),Gender varchar(max))

---1) Write a query to get all employee detail from "EmployeeDetail" table
select*from Empdetails

---2) Write a query to get only "FirstName" column from "EmployeeDetail" table
select FirstName from Empdetails

---3) Write a query to get FirstName in upper case as "First Name".
SELECT UPPER(FirstName)'First Name' from Empdetails

---4) Write a query to get FirstName in Lower case as "First Name".
select lower(FirstName)'First name' from Empdetails

---5) Write a query for combine FirstName and LastName and display it as "Name" 
---(also include white space between first name & last name)
select CONCAT(FirstName,' ',LastName)'Name' from Empdetails

----6) Select employee detail whose name is "Vikas
select*from Empdetails where FirstName='Vikas' 

---7) Get all employee detail from EmployeeDetail table whose "FirstName" start with latter 'a'.
select*from Empdetails where FirstName like 'a%'

-----9. Get all employee details from EmployeeDetail table whose "FirstName" end with 'h'
select*from Empdetails where FirstName like '%h'

----10) Get all employee detail from EmployeeDetail table whose "FirstName" start with any single character between 'a-p'
select*from Empdetails where FirstName lIKE '[A-P]%'
select*from Empdetails where FirstName between 'A' and 'P'

--11.Get all employee detail from EmployeeDetail table whose "FirstName" not start with any single character between 'a-p'
select*from Empdetails where FirstName not between 'A' AND 'P'

---12)	 Get all employee detail from EmployeeDetail table whose "Gender" end with 'le' and contain 4 letters.
---The Underscore(_) Wildcard Character represents any single character
select*, right(Gender,4)'Gender'from Empdetails 
select*from Empdetails where gender like'__le'

---13)	 Get all employee detail from EmployeeDetail table whose "FirstName" start with 'A' and contain 5 letters
select*from Empdetails where FirstName like 'A____'

---14)	 Get all employee detail from EmployeeDetail table whose "FirstName" containing '%'. ex:-"Vik%as".
select*from Empdetails where FirstName like '%[%]%'

select*from Empdetails

---15)	 Get all unique "Department" from EmployeeDetail table
select distinct (Department) from Empdetails

--16)Get the highest "Salary" from EmployeeDetail table.
select max(salary)'Highest Salry' from Empdetails

---17)	 Get the lowest "Salary" from EmployeeDetail table
select min(Salary) 'Min Salary' from Empdetails

----18)	 Show "JoiningDate" in "dd mmm yyyy" format, ex- "15 Feb 2013
select*from Empdetails
select convert(varchar(max),getdATE(),(106)) from Empdetails	
select JoiningDate, convert(varchar(20),JoiningDate, 106) from Empdetails

---19)	Show "JoiningDate" in "yyyy/mm/dd" format, ex- "2013/02/15"
select CONVERT(varchar(20),JoiningDate,(111)) from [Empdetails]

---20)	 Show only time part of the "JoiningDate"
select convert(varchar(20),JoiningDate,(108))'Joining date' from Empdetails

---21)	Get only Year part of "JoiningDate"
select year(JoiningDate) from Empdetails

---22)	Get only Month part of "JoiningDate�
select MONTH(JoiningDate)'Month'from Empdetails

---23)	Get system date
select getdate()
select CURRENT_TIMESTAMP

---24)	Get UTC date.
select GETUTCDATE()
SELECT FirstName,GETDATE()'CurrentDate',JoiningDate from Empdetails

---25)	Get the first name, current date, joiningdate and diff between current date and joining date in days.


---26)Get all employee details from EmployeeDetail table whose joining year is 2013
SELECT*fROM Empdetails where DATEPART(YYYY,JoiningDate)=2013

---29)	Get how many employee exist in "EmployeeDetail" table
select count(FirstName)'Employee' from Empdetails

---30 Select only one/top 1 record from "EmployeeDetail" table
select Top 1 * from Empdetails

--32. Select all employee detail with First name "Vikas","Ashish", and "Nikhil".
select* from Empdetails where FirstName in ('Vikas','Ashish','Nikhil')

--33. Select all employee detail with First name not in "Vikas","Ashish", and "Nikhil"
select* from Empdetails where FirstName  not in ('Vikas','Ashish','Nikhil')

---34. Select first name from "EmployeeDetail" table after removing white spaces from right side
select RTRIM(FirstName) as FirstName from Empdetails

---35. Select first name from "EmployeeDetail" table after removing white spaces from left side
select LTRIM(FirstName) as FirstName from Empdetails

----36. Display first name and Gender as M/F.(if male then M, if Female then F)
select FirstName, Gender, case Gender when 'Female' then 'F' WHEN 'MALE' THEN 'M' end as LatestGender from Empdetails

---37. Select first name from "EmployeeDetail" table prifixed with "Hello
Select 'Hello'+ ' '+  FirstName from Empdetails

----38. Get employee details from "EmployeeDetail" table whose Salary greater than 600000
select*from Empdetails where Salary>600000

---39. Get employee details from "EmployeeDetail" table whose Salary less than 700000
SELECT*FROM Empdetails where Salary<700000

----40. Get employee details from "EmployeeDetail" table whose Salary between 500000 than 600000
select*from Empdetails where Salary between 500000 and 600000

create table ProjectDetails (ProjectDetailId int,EmployeeDetailId int,ProjectName varchar(max))
----41. Give records of ProjectDetail table
select*from ProjectDetails

-------42. Write the query to get the department and department wise total(sum) salary from "EmployeeDetail" table.
SELECT*FROM Empdetails
SELECT Department, Sum(Salary) as 'total Salary' from Empdetails
Group By Department

---43. Write the query to get the department and department wise total(sum) salary, display it in ascending order according to salary.
select Department, Sum(Salary) as 'total Salary' from Empdetails
group by Department 
order by 'total Salary' asc

----44. Write the query to get the department and department wise total(sum) salary, display it in descending order according to salary
select Department, Sum(Salary) as 'total Salary' from Empdetails
group by Department
order by 'total Salary' desc

---45. Write the query to get the department, total no. of departments, total(sum) salary with respect to department from "EmployeeDetail" table.
SELECT*FROM Empdetails
select COUNT(Distinct department) 'Department', Sum(Salary) as 'total Salary' from Empdetails

---46. Get department wise average salary from "EmployeeDetail" table order by salary ascending
select Department, AVG(Salary)  as 'Average Salary' from Empdetails
group by Department
order by 'average salary' asc

---47 Get department wise maximum salary from "EmployeeDetail" table order by salary ascending
select Department, max(Salary) as 'Max Salary' from Empdetails
group by Department
order by 'max Salary' asc

----48.Get department wise minimum salary from "EmployeeDetail" table order by salary ascending.
select department, min(salary) as 'Min Salary' from Empdetails
group by Department
order by 'Min Salary' asc

-----49. Get department wise minimum salary from "EmployeeDetail" table order by salary ascending
select department, min(salary) as 'Min Salary' from Empdetails
group by Department
order by 'Min Salary' desc

----50. Join both the table that is Employee and ProjectDetail based on some common paramter
select*from Empdetails
select*from ProjectDetails

select Empdetails.EmployeeId, ProjectDetails.ProjectDetailId from Empdetails
inner Join ProjectDetails
on Empdetails.EmployeeId=ProjectDetails.ProjectDetailId

---51. Get employee name, project name order by firstname from "EmployeeDetail" and "ProjectDetail"
--for those employee which have assigned project already.
select*from Empdetails
select*from ProjectDetails

select FirstName, ProjectName from Empdetails A
inner join ProjectDetails B
ON A.EmployeeId=B.EmployeeDetailId
ORDER BY FirstName

--52. Get employee name, project name order by firstname from "EmployeeDetail" and "ProjectDetail"
--for all employee even they have not assigned project.
select*from Empdetails
select*from ProjectDetails

Select Empdetails.FirstName, ProjectDetails.ProjectName from Empdetails
left join ProjectDetails 
on Empdetails.EmployeeId=projectdetails.EmployeeDetailId
order by FirstName

--53) Get employee name, project name order by firstname from "EmployeeDetail" and "ProjectDetail" for all employee 
--if project is not assigned then display "-No Project Assigned"
select*from Empdetails
select*from ProjectDetails

select Empdetails.FirstName, ISNULL(ProjectName,'No Project Assigned') ' Project' from Empdetails
left join ProjectDetails
on Empdetails.EmployeeId=ProjectDetails.EmployeeDetailId
order By FirstName

---54.Get all project name even they have not matching any employeeid, in left table, order by firstname from "EmployeeDetail" 
---and "ProjectDetail
select Empdetails.FirstName, ProjectDetails.ProjectName from ProjectDetails
left join Empdetails
on Empdetails.EmployeeId=ProjectDetails.EmployeeDetailId
order by FirstName

----55. Get complete record (employeename, project name) from both tables ([EmployeeDetail],[ProjectDetail]), -
--if no match found in any table then show NULL

select*from Empdetails
select*from ProjectDetails

select Empdetails.FirstName,ProjectDetails.ProjectName from Empdetails
full join ProjectDetails
on Empdetails.EmployeeId=ProjectDetails.EmployeeDetailId
order by FirstName

---58.Write down the query to fetch EmployeeName & Project who has assign more than one project

select Empdetails.EmployeeId,Empdetails.FirstName,ProjectDetails.ProjectName from Empdetails
inner join ProjectDetails
on Empdetails.EmployeeId=ProjectDetails.EmployeeDetailId
where EmployeeId in (select EmployeeDetailId from ProjectDetails
group by EmployeeDetailId having count(*)>1)

----59. Write down the query to fetch ProjectName on which more than one employee are working along with EmployeeName

select Empdetails.FirstName,ProjectDetails.ProjectName from ProjectDetails
inner join Empdetails
on Empdetails.EmployeeId=ProjectDetails.EmployeeDetailId
where ProjectName in (select ProjectName from ProjectDetails
group by ProjectName having count(1)>1)

--60. Apply Cross Join in Both the tables

select*from Empdetails
select*from ProjectDetails

select*from Empdetails
cross join  ProjectDetails