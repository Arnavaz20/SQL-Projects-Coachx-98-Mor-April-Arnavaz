--Task 2
--1.	Write a query to retrieve the top 5 customers who have placed the highest total quantity of orders.
select Top 5 Customer.Name1, sum(orders.Quantity)'No of Products Ordered' from Customer
join Orders
on Customer.customer_id=orders.customer_id
group by Customer.Name1
order by 'No of Products Ordered' desc

select*from Customer
select*from Products
select*from Orders
 
---2.	Write a query to calculate the average price of products for each product category.
select p.Product_name, avg(p.Price) [Average Price] from Products p (nolock) join Products pc (nolock) on p.Product_Id = pc.Product_Id group by p.Product_Id, p.Product_name

---3.	Write a query to retrieve the customers who have not placed any orders.
select*from Customer where customer_id not in (select customer_id from Orders)

----4.	Write a query to retrieve the order details (OrderID, ProductName, Quantity) 
---for orders placed by customers whose names start with 'M'.
select orders.order_id,orders.ProductName,orders.Quantity from Customer
join Orders
on customer.customer_id=orders.customer_id
where Customer.Name1 like 'M%'

---5.	Write a query to calculate the total revenue generated from all orders.
select sum(o.Quantity * p.Price) [Total Revenue] from Orders o (nolock) join Products p(nolock) on p.Product_name = o.ProductName  

----6.	Write a query to retrieve the customer names along with the total revenue generated from their orders.
select c.Name1 [Customer Name], sum(o.Quantity * p.Price) [Total Revenue] from Customer c (nolock) join Orders o (nolock) on o.customer_id=c.customer_id join Products p(nolock) on p.Product_name = o.ProductName  group by c.Name1

----7.	Write a query to retrieve the customers who have placed at least one order for each product category.
--7. Write a query to retrieve the customers who have placed at least one order for each product category.
select c.customer_id, c.Name1 from Customer c (nolock) join Orders o on c.customer_id = o.customer_id join Products p on o.ProductName = p.Product_name group by c.customer_id, c.Name1 having count(distinct p.Product_Id) = (select count(*) from Products);

--8. Write a query to retrieve the customers who have placed orders on consecutive days.
select  distinct c.customer_id, c.Name1 from Customer c (nolock) join Orders o1 (nolock) on c.customer_id = o1.customer_id
join Orders o2 (nolock) on c.customer_id = o2.customer_id AND o2.OrderDate = dateadd(day,1,o1.OrderDate)

--9. Write a query to retrieve the top 3 products with the highest average quantity ordered.
select top 3 avg(Quantity) as [Average Quantity], ProductName from orders (nolock) group by ProductName order by [Average Quantity] desc

--10 Write a query to calculate the percentage of orders that have a quantity greater than the average quantity.
select count(*) * 100.0 / (select count(*) from Orders) as [Percentage] from Orders where Quantity > (select avg(Quantity) from Orders)