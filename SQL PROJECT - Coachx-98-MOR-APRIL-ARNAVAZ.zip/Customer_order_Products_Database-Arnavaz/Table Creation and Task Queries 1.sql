create table Customer(customer_id int primary key, Name1 varchar(50), email varchar(100))

insert into Customer values (1, 'John Doe', 'johndoe@example.com'),(2, 'Jane Smith', 'janesmith@example.com'),(3, 'Robert Johnson', 'robertjohnson@example.com'),
(4, 'Emily Brown', 'emilybrown@example.com'),(5, 'Michael Davis', 'michaeldavis@example.com'),(6, 'Sarah Wilson', 'sarahwilson@example.com'),
(7, 'David Thompson', 'davidthompson@example.com'),(8, 'Jessica Lee', 'jessicalee@example.com'),(9, 'William Turner', 'williamturner@example.com'),
(10, 'Olivia Martinez', 'oliviamartinez@example.com');

create table Orders(order_id int primary key, customer_id int, ProductName varchar(50),orderdate Date, Quantity int)

insert into Orders values (1, 1, 'Product A', '2023-07-01', 5),(2, 2, 'Product B', '2023-07-02', 3),(3, 3, 'Product C', '2023-07-03', 2),
(4, 4, 'Product A', '2023-07-04', 1),(5, 5, 'Product B', '2023-07-05', 4),(6, 6, 'Product C', '2023-07-06', 2),(7, 7, 'Product A', '2023-07-07', 3),
(8, 8, 'Product B', '2023-07-08', 2),(9, 9, 'Product C', '2023-07-09', 5),(10, 10, 'Product A', '2023-07-10', 1);

create Table Products(Product_Id int primary key,Product_name varchar(50), Price Decimal (10,2))

insert into Products values  (1, 'Product A', 10.99),(2, 'Product B', 8.99),(3, 'Product C', 5.99),(4, 'Product D', 12.99),(5, 'Product E', 7.99),
(6, 'Product F', 6.99),(7, 'Product G', 9.99),(8, 'Product H', 11.99),(9, 'Product I', 14.99),(10, 'Product J', 4.99);


select*from Customer
select*from Products
select*from Orders

----Task 1 
---1.	Write a query to retrieve all records from the Customers table..
select*from Customer

-----2.	Write a query to retrieve the names and email addresses of customers whose names start with 'J'.

select Name1, email from Customer where Name1 like 'J%'

---3.	Write a query to retrieve the order details (OrderID, ProductName, Quantity) for all orders..
select Order_id, ProductName, Quantity from Orders

---4.	Write a query to calculate the total quantity of products ordered.
select sum(Distinct Quantity)'Total Quantity' from Orders

select*from Customer
select*from Products
select*from Orders

---5.	Write a query to retrieve the names of customers who have placed an order.

select * from Customer  where customer_id in (Select customer_id from Orders)

---6.	Write a query to retrieve the products with a price greater than $10.00.
select*from Products where Price>10.00

---7.	Write a query to retrieve the customer name and order date for all orders placed on or after '2023-07-05'.
select Customer.Name1, Orders.orderdate from Customer
join Orders
on Customer.customer_id=orders.customer_id
where orderdate>='2023-07-05'

----8.	Write a query to calculate the average price of all products.
select AVG(price)'Avg Price' from Products

---9.	Write a query to retrieve the customer names along with the total quantity of products they have ordered.
select Customer.Name1, sum(orders.Quantity) 'Total Quantity' from Customer
join Orders
on Customer.customer_id=orders.customer_id
group by customer.Name1

----10.	Write a query to retrieve the products that have not been ordered.
select*from Products where Product_name not in (select Product_name from Orders)